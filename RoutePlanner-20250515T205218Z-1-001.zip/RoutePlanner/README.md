An Android Map application that finds the shortest route between multiple locations. 
Now you can enter not only addresses, but also place names!

<img src="https://github.com/KaiSun314/RoutePlanner/blob/master/screenshots/Explore.png" width="250"> <img src="https://github.com/KaiSun314/RoutePlanner/blob/master/screenshots/Add.png" width="250"> <img src="https://github.com/KaiSun314/RoutePlanner/blob/master/screenshots/Edit%20and%20Optimize.png" width="250"> <img src="https://github.com/KaiSun314/RoutePlanner/blob/master/screenshots/Calculating%20Route.png" width="250"> <img src="https://github.com/KaiSun314/RoutePlanner/blob/master/screenshots/Directions.png" width="250">
